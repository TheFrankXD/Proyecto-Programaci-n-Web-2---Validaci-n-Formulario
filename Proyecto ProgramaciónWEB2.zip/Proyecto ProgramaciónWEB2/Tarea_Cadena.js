//1
let desafio = "curso de JavaScript con Kevin";

//2
console.log(desafio);

//3
console.log(desafio.length);

//4
console.log(desafio.toUpperCase());

//5
console.log(desafio.toLowerCase());

//6
console.log(desafio.substring(0, 5));

//7
console.log(desafio.replace("JavaScript", "")); 

//8
console.log(desafio.includes("Script")); // true

//9
console.log(desafio.split(""));

//10
console.log(desafio.split(" "));
